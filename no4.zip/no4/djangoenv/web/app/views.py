from django.shortcuts import render
from datetime import datetime


def no4(request):
    now = datetime.now()
    return render(request, 'no4.html', locals())

def hello(request):
    now = datetime.now()
    return render(request, 'hello_django.html',locals())

def home(request):
    now = datetime.now()
    return render(request, 'home.html', locals())


